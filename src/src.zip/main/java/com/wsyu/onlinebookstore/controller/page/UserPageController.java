package com.wsyu.onlinebookstore.controller.page;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/user")
public class UserPageController {
    @RequestMapping("/cart")
    public String cart() {
        return "/user/cart";
    }
    
    @RequestMapping("/index")
    public String index() {
        return "/user/index";
    }
    
    @RequestMapping("/myOrderList")
    public String myOrderList() {
        return "/user/myOrderList";
    }
    
    @RequestMapping("/orderSuccess")
    public String orderSuccess() {
        return "/user/orderSuccess";
    }
}
