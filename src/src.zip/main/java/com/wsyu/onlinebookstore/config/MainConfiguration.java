package com.wsyu.onlinebookstore.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
@ComponentScan("com.wsyu.onlinebookstore")
@Configuration
public class MainConfiguration {

}
